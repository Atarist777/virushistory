@rem = '--*-Perl-*--
@echo off
if "%OS%" == "Windows_NT" goto WinNT
perl -x -S "%0" %1 %2 %3 %4 %5 %6 %7 %8 %9
goto endofperl
:WinNT
perl -x -S "%0" %*
if NOT "%COMSPEC%" == "%SystemRoot%\system32\cmd.exe" goto endofperl
if %errorlevel% == 9009 echo You do not have Perl in your PATH.
goto endofperl
@rem ';
#!perl -w
#line 14

use strict;

my($self,$fill,$item,$file,$why,$size,$buffer,$address,$read,$offset,$line);

$self = $0;
$self =~ s!^.*[/\\]!!;

$fill = 0x2E;

die "Usage: $self <file> [<file> ...]\n" unless (@ARGV);

foreach $item (@ARGV)
{
    FILE:
    foreach $file (glob($item))
    {
        unless (open(FILE, "<$file"))
        {
            warn "$self: can't read file '$file': $!\n";
            next FILE;
        }
        unless (binmode(FILE))
        {
            $why = "$!";
            unless (close(FILE))
            {
                warn "$self: can't close file '$file': $!\n";
            }
            warn "$self: can't set binmode for file '$file': $why\n";
            next FILE;
        }
        $size = -s FILE;
        $size = 1024 if ($size < 1024);
        $size = 32768 if ($size > 32768);
        $buffer = ' ' x $size;
        if (@ARGV > 1)
        {
            print "$file:\n";
            print '-' x 78, "\n";
        }
        $address = 0;
        init_line(\$address);
        CHUNK:
        while (1)
        {
            unless (defined ($read = sysread(FILE,$buffer,$size)))
            {
                $why = "$!";
                unless (close(FILE))
                {
                    warn "$self: can't close file '$file': $!\n";
                }
                warn "$self: can't sysread from file '$file': $why\n";
                next FILE;
            }
            last CHUNK unless ($read > 0);
            for ( $offset = 0; $offset < $read; $offset++ )
            {
                print_byte(\$address,ord(substr($buffer,$offset,1)));
            }
        }
        print_line(\$address) if ($address & 0x0F);
        print '-' x 78, "\n" if (@ARGV > 1);
        unless (close(FILE))
        {
            warn "$self: can't close file '$file': $!\n";
        }
    }
}

sub init_line
{
    my($address) = @_;

    $line =
    sprintf("%08X:                                                                     ",
#       "00000000: 00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  ................"
#       "012345678901234567890123456789012345678901234567890123456789012345678901234567"
#       "0         1         2         3         4         5         6         7       "
    ${$address});
}

sub print_line
{
    my($address) = @_;

    print "$line\n";
    init_line($address);
}

sub print_byte
{
    my($address,$byte) = @_;
    my($n,$p,$c);

    $n = ${$address}++ & 0x0F;
    $p = 10 + $n + ($n << 1) + ($n >> 2);
    substr($line,$p,2) = sprintf("%02X", $byte);
    $p = 62 + $n;
    if (($byte <= 0x1F) ||
        (($byte >= 0x7F) && ($byte <= 0x9F))) { $c = chr($fill); }
    else                                      { $c = chr($byte); }
    substr($line,$p,1) = $c;
    print_line($address) unless (${$address} & 0x0F);
}

__END__
:endofperl
