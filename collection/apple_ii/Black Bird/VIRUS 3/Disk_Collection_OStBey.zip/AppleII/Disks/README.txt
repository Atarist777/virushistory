BAGTRCKS.DSK
  Contains several utilities, some of which come from the famous book "Bag Of Tricks" by Worth & Lechner.
  Some utilities are from the Erphi controller for 160 track diskette drives.
  Also contains the "Big Mac" assembler.
BILDER0.DSK
BILDER1.DSK
BILDER2.DSK
BILDER3.DSK
BILDER4.DSK
  These diskette images contain a collection of hi-res pictures; press any key to advance to the next picture of the slideshow.
DISK6A.DSK
  Contains a self-written program for the classic naval combat game; written in machine language (not in assembler!).
  The sound of the shots is actually the program code played back via the speaker in varying speeds.
DISK6B.DSK
  Contains a demo version of the above classic naval combat game; with sounds.
DISK6C.DSK
  Contains a demo version of the above classic naval combat game; without sounds to show the impressive speed.
ELITE.DSK
  Contains the game "Elite", in which you must make profits as an interstellar trader - very impressive graphics for the time!
FLGHTSIM.DSK
  Contains the A2-FS2 Flight Simulator.
GRAFORTH.DSK
  Contains the system and a demo of the GraForth programming language.
MATHPLOT.DSK
  Contains tools for the statistical analysis and plotting of mathematical functions.
MORSE.DSK
  Contains a self-written application for converting between Morse code and ASCII text in both directions.
  Outputs the Morse code via the Apple's speaker and cassette output port, reads in Morse code via the cassette input port.
  Press soft reset to signal when the reading should be terminated and decoding should be started.
  (Decoding at the same time while the signal is being recorded is not possible due to the slow processor speed of the 6502!)
PRODOS.DSK
  Apple's new operating system "ProDOS" with a joystick-operated first version of MacPaint.
SARGON.DSK
  Contains a chess computer program with speech output - unbelievable at the time!!!
SKAT.DSK
  Contains a computer program to play Skat.
SOUND.DSK
  Contains a program to play back and record sound coming in at the cassette input port, as well as some sample recordings S0, S1 and S2 of music by Santana.
SPIELE1.DSK
  Contains the games "Raster Blaster" (a pinball game), Pool Billard, Choplifter and the classic "naval combat" mentioned further above.
SPIELE2.DSK
  Contains the games "Reversal" (Othello), "Death Star" (Star Wars), "Space Raiders" and "Autobahn".
SPIELE3.DSK
  Contains the games "Star Trek" (with detailed instructions), the text adventure "Lost Dutchman's Gold" and a pinball game made with the pinball construction set.
SYSTEM.DSK
  Contains some system utilities whose purpose I can't recall anymore.
TI59.DSK
  Contains an editor to write programs for and a driver to transfer these programs to the TI-59 programmable pocket calculator via a self-made interface
  (which operates the calculator's keyboard and monitors whether the calculator is executing a program or is ready for keyboard input).
TICTAC.DSK
  This is actually an Apple Pascal (or UCSD Pascal) diskette. Its volume name is "BACKUP:".
  Contains the program "TICTACTOE.TEXT" which can be executed to play Tic Tac Toe.
  The program implements a learning algorithm. The more it plays, the better it gets (hopefully).
TUTOR.DSK
  This is actually an Apple Pascal (or UCSD Pascal) diskette. Its volume name is "BACKUP:".
  Contains a vocabulary training program called "APPLETUTOR.TEXT".
  Some example lesson files are provided in "L1", "L2", "L3", "L10", "L11", "L12" and "L13" in Spanish, with translations in German and French.
UCSD0.DSK
UCSD1.DSK
UCSD2.DSK
UCSD3.DSK
  The volume names of the four diskette images "UCSD0", "UCSD1", "UCSD2" and "UCSD3" are "APPLE0:", "APPLE1:", "APPLE2:" and "APPLE3:", respectively.
  These diskette images contain the Apple Pascal (or UCSD Pascal) compiler, linker, editor and other tools.
  The volume names (in ASCII) of Apple Pascal diskettes can also be found in the 16 bytes or so following position 00000B00 when you hexdump the diskette images.
